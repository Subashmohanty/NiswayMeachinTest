    <script src="js/jquery-cdn.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/intelli-input.js"></script>
    <script src="js/common.js"></script>
</body>
</html>